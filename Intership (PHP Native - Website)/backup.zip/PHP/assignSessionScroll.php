<?php
    session_start();
    $_SESSION['scroll-sidebar'] = $_GET['scroll'];
    $_SESSION['focus'] = $_GET['focus'];
?>