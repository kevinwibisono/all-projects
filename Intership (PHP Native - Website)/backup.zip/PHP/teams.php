<?php
    include("connection.php");
    date_default_timezone_set("Asia/Bangkok");
    session_start();
    $visibility = "visible"; $menuDua = "Master Project";
    $current_staff = []; $current_name = "--"; $current_id = "";
    if(isset($_SESSION['staff_login'])){
        $current_staff = $_SESSION['staff_login'];
        $current_name = $current_staff['staff_name'];
        $current_id = $current_staff['staff_id'];
        if($current_staff['flgAsAdmin'] == 0){
            $visibility = "hidden";
        }
    }
    else{
        header("location:index.php");
    }
    
    if(isset($_POST['add'])){
        $datenow = date("Y-m-d H:i:s");
        $staffName = $_POST['name'];
        $staffPassword = $_POST['password'];
        $staffPosition = $_POST['position'];
        $staffFlag = "";
        if(isset($_POST['flag'])){
            $staffFlag = 1;
        }
        else{
            $staffFlag = 0;
        }
        
        $id = "";
        $res = mysqli_query($conn, "SELECT ifnull(max(CAST(substr(staff_id, 3) AS DECIMAL)),0)+1 as max FROM master_staff");
        while($r = mysqli_fetch_array($res)){
            $id = "ST0".$r['max'];
        }
        
        $result = mysqli_query($conn, "INSERT INTO master_staff VALUES('$id', '$staffName', '$staffPassword', '$staffPosition', $staffFlag, '', '$current_name', '$datenow')");
    }

    if(isset($_POST['update'])){
        $datenow = date("Y-m-d H:i:s");
        $staffId = $_POST['id'];
        $staffName = $_POST['name'];
        $staffPassword = $_POST['password'];
        $staffPosition = $_POST['position'];
        $staffFlag = "";
        if(isset($_POST['flag'])){
            $staffFlag = 1;
        }
        else{
            $staffFlag = 0;
        }
        
        $result = mysqli_query($conn, "UPDATE master_staff SET staff_name = '$staffName', Password = '$staffPassword', staff_position = '$staffPosition', flgAsAdmin = $staffFlag, operator = '$current_name', waktuproses = '$datenow' WHERE staff_id = '$staffId'");
    }

    if(isset($_POST['delete'])){
        $id = $_POST['id'];
        
        mysqli_query($conn, "DELETE FROM master_staff WHERE staff_id='$id'");
    }

    $staffList = [];

    $result = mysqli_query($conn, "SELECT * FROM master_staff WHERE staff_id <> '$current_id' and project_id = ''");
    while($row = mysqli_fetch_array($result)){
        $data["staff_id"] = $row["staff_id"];
        $data["staff_name"] = $row["staff_name"];
        $data["Password"] = $row["Password"];
        $data["staff_position"] = $row["staff_position"];
        $data["flgAsAdmin"] = $row["flgAsAdmin"];
        $data["operator"] = $row["operator"];
        $data["waktuproses"] = $row["waktuproses"];
        
        array_push($staffList, $data);
    }
    mysqli_free_result($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="./imgicon/logo2.ico">
    <title>Project Scheduling</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="./plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="./plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="./plugins/bower_components/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
    <link href="css/graph.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
    <style>
        #tableStaffs i:hover{
            transform: scale(2);
        }
        #topBtn {
          display: none;
          position: fixed;
          bottom: 20px;
          right: 30px;
          z-index: 99;
          font-size: 18px;
          border: none;
          outline: none;
          background-color: red;
          color: white;
          cursor: pointer;
          padding: 15px;
          border-radius: 4px;
        }

        #topBtn:hover {
          background-color: #555;
        }
        
        .sorting::after{display: none;}
        
        .sorting_desc::after{display: none;}
        
        .sorting_asc::after{display: none;}
    </style>
</head>

<body class="fix-header">
    <!-- ============================================================== -->
    <!-- Preloader -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Wrapper -->
    <!-- ============================================================== -->
    <div id="wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                    <!-- Logo -->
                    <a class="logo" href="dashboard.php">
                        <!-- Logo icon image, you can use font-icon also -->
                        <b>
                            <img src="./imgicon/logo2.ico" style="width: 25px; height: 30px" alt="home" class="light-logo" />
                        </b>
                        <!-- Logo text image you can use text also -->
                        <span class="hidden-xs">
                            <h2 style="float: left; font-family: arial; padding-top: 5px; padding-left: 10px">SoftQ</h2>
                        </span> 
                    </a>
                </div>
                <!-- /Logo -->
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="nav-toggler open-close waves-effect waves-light hidden-md hidden-lg" href="javascript:void(0)"><i class="fa fa-bars"></i></a>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><img src="./imgicon/AIQ61.png" alt="user-img" width="36" class="img-circle">&nbsp;<b class="hidden-xs"><?=$current_name?></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="index.php" class="waves-effect"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;<b>Logout</b></a>
                            </li>
                        </ul>
                    </li>
                </ul>
                
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- End Top Navigation -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    <li style="padding: 70px 0 0;">
                        <a href="dashboard.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="listproject.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i>Master Project</a>
                    </li>
                    <li>
                        <a href="teams.php" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Master Staff</a>
                    </li>
                </ul>
            </div>
            
        </div>
        <!-- ============================================================== -->
        <!-- End Left Sidebar -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><a href="teams.php">List Of Staffs</a></h4></div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <button id="topBtn" title="Go to top">Top</button>
                            
                            <button style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px; margin-bottom: 10px; visibility: <?=$visibility?>" data-toggle="modal" data-target="#myModal" onclick = "displayAdd()">Add</button>
                            <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">

                                  <!-- Modal content-->
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h3 class="box-title"></h3>
                                    </div>
                                    <div class="modal-body">
                                          <div class="row">
                                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                <div class="white-box">
                                                    <form action="" method="post" id="formAdd">
                                                        Staff Name:<br><input type="text" name="name" id="addStaffName" placeholder="name"><br><br>
                                                        Staff Password:<br><input type="text" name="password" id="addStaffPassword" placeholder="name"><br><br>
                                                        Staff Position:<br><input type="text" name="position" id="addStaffPosition" placeholder="ex: Project Manager"><br><br>
                                                        <input type="checkbox" name="flag" id="addStaffFlag">&nbsp;flag this staff as admin<br><br>
                                                        <input type="submit" value="Add" style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px;" name="add">
                                                        <h3 style="color: red;" id="errorAdd"></h3>
                                                    </form>

                                                    <form action="" method="post" id="formUpdate">
                                                        Staff Id:<br><input type="text" style="border: none; font-size: 20px; text-decoration: bold;" readonly="true" name="id" id="updateStaffId"><br><br>
                                                        Staff Name:<br><input type="text" name="name" id="updateStaffName" placeholder="new name"><br><br>
                                                        Staff Password:<br><input type="text" name="password" id="updateStaffPassword" placeholder="new pass"><br><br>
                                                        Staff Position:<br><input type="text" name="position" id="updateStaffPosition" placeholder="new position"><br><br>
                                                        <input type="checkbox" name="flag" id="updateStaffFlag">&nbsp;flag this staff as admin<br><br>
                                                        <input type="submit" value="Update" style="background-color: black; color: white; border: none; border-radius: 5px; width: 75px; height: 40px;" name="update">
                                                        <h3 style="color: red;" id="errorUpdate"></h3>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            
                            <div class="table-responsive">
                                <table id="tableStaffs" class="display" style="text-align: right;">
                                    <thead>
                                        <tr>
                                            <th style="text-align: right;">#</th>
                                            <th style="text-align: right;">ACTION</th>
                                            <th style="text-align: left;">NAME</th>
                                            <th style="text-align: left;">PASSWORD</th>
                                            <th style="text-align: left;">POSITION</th>
                                            <th style="text-align: right;">FLAG ADMIN</th>
                                            <th style="text-align: left;">OPERATOR</th>
                                            <th style="text-align: center;">PROCESS TIME</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                                $ctr = 0;
                                                foreach ($staffList as $s){
                                                    $ctr++;
                                        ?>
                                                    <tr>
                                                        <td style="text-align: right;"><?=$ctr?></td>
                                                        <td>
                                                            <button data-toggle="modal" data-target="#myModal" style="border: none; background-color: transparent; float:right; visibility: <?=$visibility?>" onclick="displayUpdate(<?=$ctr?>)">
                                                                <i class="fa fa-pencil-square" style="color: blue;" aria-hidden="true"></i>
                                                            </button>
                                                            
                                                            <form method="post" id="deleteStaff<?=$ctr?>" class="deleteStaff" style="float:right;" >
                                                                <input type="hidden" name="id" value="<?=$s['staff_id']?>" id="staffId<?=$ctr?>">
                                                                <button type="submit" name="delete" style="border: none; background-color: transparent; visibility: <?=$visibility?>">
                                                                    <i class="fa fa-trash" style="color: red;" aria-hidden="true"></i>
                                                                </button>
                                                            </form>
                                                        </td>
                                                        <td style="text-align: left;" id="staffName<?=$ctr?>"><?=$s['staff_name']?></td>
                                                        <td style="text-align: left;" id="staffPassword<?=$ctr?>"><?=$s['Password']?></td>
                                                        <td style="text-align: left;"><?=$s['staff_position']?></td>
                                                        <td style="text-align: right;"><?=$s['flgAsAdmin']?></td>
                                                        <td style="text-align: left;"><?=$s['operator']?></td>
                                                        <td style="text-align: center;"><?=$s['waktuproses']?></td>
                                                    </tr>
                                        <?php
                                                }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="./plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="./plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="./plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="./plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="./plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <!-- MDBootstrap Datatables  -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script>
        var arrStaff = [];
        $(document).ready(function () {
            $.ajax({
               url: "./json/jsonStaff.php",
               success: function(data){
                   arrStaff = JSON.parse(data);
               },
               type: 'GET'
            });

            $('#tableStaffs').DataTable({
                "lengthMenu": [[-1, 10, 25, 50], ["All", 10, 25, 50]]
            });
            
            $("#formAdd").submit(function(event){
                var staffName = $("#addStaffName").val();
                var staffPassword = $("#addStaffPassword").val();
                var staffPosition = $("#addStaffPosition").val();
                if(staffName == "" || staffPassword == "" || staffPosition == ""){
                    $("#errorAdd").html("Fields must not be null");
                    event.preventDefault();
                }
                else{
                    staffName = staffName.toLowerCase();
                    staffPassword = staffPassword.toLowerCase();
                    if(staffName.indexOf(staffPassword) > -1){
                        $("#errorAdd").html("Pick stronger password");
                        event.preventDefault();
                    }
                    else if(staffPassword.indexOf(staffName) > -1){
                        $("#errorAdd").html("Pick stronger password");
                        event.preventDefault();
                    }
                }
            });
            
            $(".deleteStaff").submit(function(){
                 var id = jQuery(this).attr("id");
                 id = id.substr(11);
                 var staffName = $("#staffName"+id).html();
                 var cfr = confirm("Are you sure you want delete "+staffName+"?");
                 if(!cfr){
                     event.preventDefault();
                 }
            });
            
            $("#formUpdate").submit(function(event){
                var staffName = $("#updateStaffName").val();
                var staffPassword = $("#updateStaffPassword").val();
                var staffPosition = $("#updateStaffPosition").val();
                if(staffName == "" || staffPassword == "" || staffPosition == ""){
                    $("#errorUpdate").html("Fields must not be null");
                    event.preventDefault();
                }
                else{
                    staffName = staffName.toLowerCase();
                    staffPassword = staffPassword.toLowerCase();
                    if(staffName.indexOf(staffPassword) > -1){
                        $("#errorUpdate").html("Pick stronger password");
                        event.preventDefault();
                    }
                    else if(staffPassword.indexOf(staffName) > -1){
                        $("#errorUpdate").html("Pick stronger password");
                        event.preventDefault();
                    }
                }               
            });
            
            $("#topBtn").click(function(){
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            });
        });
        
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            $("#topBtn").css("display", "block");
          } else {
            $("#topBtn").css("display", "none");
          }
        }
        
        function displayUpdate(num){
            $("#formUpdate").css("display", "block");
            $("#formAdd").css("display", "none");
            var staffId = $("#staffId"+num).val();
            var staff = [];
            arrStaff.forEach(s => {
                if(s['staff_id'] == staffId){
                    staff = s;
                }
            });
            if(staff['flgAsAdmin'] == 0){
                $("#updateStaffFlag").prop("checked", false);
            }
            else if(staff['flgAsAdmin'] == 1){
                $("#updateStaffFlag").prop("checked", true);
            }
            $("#updateStaffId").val(staff['staff_id']);
            $("#updateStaffName").val(staff['staff_name']);
            $("#updateStaffPassword").val(staff['Password']);
            $("#updateStaffPosition").val(staff['staff_position']);
        }

        function displayAdd(){
            $("#formUpdate").css("display", "none");
            $("#formAdd").css("display", "block");
        }
            
    </script>
</body>
</html>