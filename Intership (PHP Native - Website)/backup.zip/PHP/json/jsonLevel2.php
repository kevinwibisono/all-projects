<?php
    include("../connection.php");

    $subdetailList = [];

    $projectid = $_GET['project_id'];

    $result = mysqli_query($conn, "SELECT l2.* FROM project_detail_l2 l2, project_detail_l1 l1 WHERE l2.detail_id = l1.detail_id and l1.project_id = '$projectid' ORDER BY step");
    while($row = mysqli_fetch_array($result)){
        $data["detail_id"] = $row["detail_id"];
        $data["sub_detail_id"] = $row["sub_detail_id"];
        $data["sub_detail_name"] = $row["sub_detail_name"];
        $data["sub_detail_start"] = $row["sub_detail_start"];
        $data["sub_detail_end"] = $row["sub_detail_end"];
        $data["staff_id"] = $row["staff_id"];
        $data["staff_note"] = $row["staff_note"];
        $data["flag"] = $row["flag"];
        $data["predecessor"] = $row["predecessor"];
        $data["step"] = $row["step"];
        
        array_push($subdetailList, $data);
    }
    mysqli_free_result($result);

    echo json_encode($subdetailList);
?>