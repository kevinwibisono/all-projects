<?php
    include("../connection.php");

    $staffList = [];

    $result = mysqli_query($conn, "SELECT * FROM master_staff");
    while($row = mysqli_fetch_array($result)){
        $data["staff_id"] = $row["staff_id"];
        $data["staff_name"] = $row["staff_name"];
        $data["Password"] = $row["Password"];
        $data["staff_position"] = $row["staff_position"];
        $data["flgAsAdmin"] = $row["flgAsAdmin"];
        
        array_push($staffList, $data);
    }
    mysqli_free_result($result);

    echo json_encode($staffList);
?>