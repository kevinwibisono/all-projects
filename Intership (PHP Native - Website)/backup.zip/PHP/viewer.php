<?php
    include("connection.php");
    $chosen_project;
    //dapatkan project yang dimaksud
    $result = mysqli_query($conn, "SELECT *, DATE_ADD(start_date, INTERVAL project_duration DAY) as target_end FROM project_header WHERE project_id = '".$_GET['project_id']."'");
    while($res = mysqli_fetch_array($result)){
        $chosen_project['project_id'] = $res['project_id'];
        $chosen_project['project_name'] = $res['project_name'];
        $chosen_project['project_total'] = $res['project_total'];
        $chosen_project['start_date'] = $res['start_date'];
        $chosen_project['project_duration'] = $res['project_duration'];
        $chosen_project['target_end'] = $res['target_end'];
    }
    $current_name = "--";

    if(isset($chosen_project)){
        
        $operator = ""; $waktuproses = "0000-00-00 00:00:00"; $scrollTop = 0;
        $dividerSize = "500px"; $divSize = "500px";
        $jumSubDetail = 0;

        $query = "SELECT * FROM project_detail_l1 WHERE project_id = '".$chosen_project['project_id']."' ORDER BY step";

        //get Level 1 and Level 2 of project
        $level1 = [];
        $level2 = [];
        $adjusts = [];
        $files = [];
        
        $result = mysqli_query($conn, "SELECT * FROM project_files WHERE project_id = '".$chosen_project['project_id']."' ORDER BY waktuproses DESC");
        while($row = mysqli_fetch_array($result)){
            $data["file_id"] = $row["file_id"];
            $data["project_id"] = $row["project_id"];
            $data["filename"] = $row["filename"];
            $data["operator"] = $row["operator"];
            $data["waktuproses"] = $row["waktuproses"];
            array_push($files, $data);
        }

        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_array($result)){
            $id = $row["detail_id"];
            $data["detail_id"] = $row["detail_id"];
            $data["detail_name"] = $row["detail_name"];
            $data["detail_start"] = $row["detail_start"];
            $data["detail_end"] = $row["detail_end"];
            $data["step"] = $row["step"];
            array_push($level1, $data);
        }

        $res = mysqli_query($conn, "SELECT l2.*, s.staff_name FROM project_detail_l2 l2 LEFT JOIN master_staff s ON (l2.staff_id = s.staff_id) WHERE detail_id IN (SELECT detail_id FROM project_detail_l1 WHERE project_id = '".$chosen_project['project_id']."') ORDER BY step");
        while($r = mysqli_fetch_array($res)){
            $jumSubDetail++;
            $sub["detail_id"] = $r["detail_id"];
            $sub_id = $r["sub_detail_id"];
            $sub["sub_detail_id"] = $r["sub_detail_id"];
            $sub["sub_detail_name"] = $r["sub_detail_name"];
            $sub["sub_detail_start"] = $r["sub_detail_start"];
            $sub["sub_detail_end"] = $r["sub_detail_end"];
            $sub["staff_note"] = $r["staff_note"];
            $sub["flag"] = $r["flag"];
            $sub["staff_id"] = $r["staff_id"];
            $sub["step"] = $r["step"];
            $sub["staff_name"] = $r["staff_name"];
            $operator = $r['operator'];
            $waktuproses = $r['waktuproses'];

            array_push($level2, $sub);

            $adjustquery = mysqli_query($conn, "SELECT * FROM project_adjust WHERE sub_detail_id = '$sub_id'");
            while($a = mysqli_fetch_array($adjustquery)){
                $ad["adjust_id"] = $a["adjust_id"];
                $ad["sub_detail_id"] = $a["sub_detail_id"];
                $ad["adjust_duration"] = $a["adjust_duration"];
                $ad["adjust_comment"] = $a["adjust_comment"];
                array_push($adjusts, $ad);
            }
        }

        $dividerSize = ($jumSubDetail*50+100);
        $divSize = ($jumSubDetail*60+120);

        $staffList = [];

        $maxL1Duration = $chosen_project['project_duration'];
        $ulSize = (($maxL1Duration+1)*100)."px";

        $result = mysqli_query($conn, "SELECT * FROM master_staff");
        while($row = mysqli_fetch_array($result)){
            $data["staff_id"] = $row["staff_id"];
            $data["staff_name"] = $row["staff_name"];

            array_push($staffList, $data);
        }
        mysqli_free_result($result);
    }
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="./imgicon/logo2.ico">
    <title>Project Scheduling</title>
    <!-- Semantic UI CSS (for popup)-->
    <link href="css/semantic.min.css" rel="stylesheet">
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Menu CSS -->
    <link href="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="./plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="./plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="./plugins/bower_components/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
    <link href="css/graph.css" rel="stylesheet">
    
    <style>  
        body{
          overflow-y: hidden;
        }
        
        .singleFile{
            border: 1px solid black;
            margin: 10px;
            padding: 5px;
            max-height: 32px;
            max-width: 300px;
            float: left;
        }
        
        .fileDate{
            float: left;
            margin-top: 15px;
        }
        
        .dropdown-content {
          display: none;
          position: absolute;
          background-color: #f1f1f1;
          min-width: 160px;
          box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
          z-index: 99;
        }
        
        .dropdown-content li {
          color: black;
          padding: 12px 16px;
          text-decoration: none;
          display: block;
        }
        
        :root {
          --divider: lightgrey;
        }

        ul {
          list-style: none;
        }

        a {
          text-decoration: none;
          color: inherit;
        }

        #chart-container {
            height: <?=$divSize?>;
            clear: both;
            padding-top: 20px;
        }
        
        #chart-header{
            overflow: hidden;
        }
        
        #task-container{
            overflow: auto;
            height: <?=($divSize-20)."px"?>;
        }

        .chart-values {
            position: relative;
            display: flex;
            padding: 0px;
            font-weight: bold;
            font-size: 1.2rem;
            width: <?=$ulSize?>;
            margin: auto;
            margin-bottom: 20px;
        }

        .chart-values li {
            flex: 1;
            text-align: center;
        }

        .chart-values li:not(:last-child) {
            position: relative;
        }

        .chart-values li:not(:last-child)::before {
            content: '';
            position: absolute;
            right: 0;
            height: <?=$dividerSize."px"?>;
            border-right: 1px solid var(--divider);
        }
        
        .chart-values-hidden {
            position: relative;
            display: flex;
            padding: 0px;
            font-weight: bold;
            font-size: 1.2rem;
            width: <?=$ulSize?>;
            margin: auto;
            margin-bottom: 20px;
        }

        .chart-values-hidden li {
            flex: 1;
            text-align: center;
        }

        .chart-values-hidden li:not(:last-child) {
            position: relative;
        }

        .chart-values-hidden li:not(:last-child)::before {
            content: '';
            position: absolute;
            right: 0;
            height: <?=$dividerSize."px"?>;
            border-right: 1px solid var(--divider);
        }
        
        .chart-bars{
            width: <?=$ulSize?>;
            padding: 0px;
            margin: auto;
        }

        .chart-bars li div{
            position: relative;
            display: inline-block;
            max-height: 37px;
            margin-bottom: 15px;
            font-size: 12px;
            border-radius: 20px;
            padding: 10px;
            color: white;
            font-weight: bold;
        }

        .chart-individual:hover{
            border: 2px solid black;
            box-sizing: border-box;
        }

        .chart-individual .resizers{
            display: none;
            width: 17px;
            height: 17px;
            top: 10px;
            background-color: white;
            position: absolute;
            border-radius: 50%;
            border: 2px solid black;
            cursor: ew-resize;
        }

        .chart-individual .upanddown{
            display: none;
            width: 30px;
            height: 20px;
            text-align: center;
            background-color: white;
            position: absolute;
            border-radius: 25%;
            border: 2px solid black;
            cursor: pointer;
        }
        
        .legend{
            width: 10px;
            height: 10px;
            margin: 0;
        }
        
        .dragger{
            overflow: hidden;
            word-break: break-all;
            max-width: 20px;
            max-height: 17px;
        }
    </style>
</head>

<body class="fix-header">
    <!-- Preloader -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="5000" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <!-- Wrapper -->
    <div id="wrapper">
        <!-- Topbar header - style you can find in pages.scss -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                    <a class="logo">
                        <!-- Logo icon image, you can use font-icon also -->
                        <b>
                            <img src="./imgicon/logo2.ico" style="width: 25px; height: 30px" alt="home" class="light-logo" />
                        </b>
                        <!-- Logo text image you can use text also -->
                        <span class="hidden-xs">
                            <h2 style="float: left; font-family: arial; padding-top: 15px; padding-left: 10px">SoftQ</h2>
                        </span> 
                    </a>
                </div>
                <!-- User login -->
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="nav-toggler open-close waves-effect waves-light hidden-md hidden-lg" href="javascript:void(0)"><i class="fa fa-bars"></i></a>
                    </li>
                    <li>
                        <a><img src="./imgicon/AIQ61.png" alt="user-img" width="36" class="img-circle">&nbsp;<b class="hidden-xs"><?=$current_name?></b></a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- End Top Navigation -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <?php
            if(isset($chosen_project)){
                ?>
                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav slimscrollsidebar" id="sidebarDiv">
                        <div class="sidebar-head">
                            <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                        </div>
                        <ul class="nav" id="side-menu" style="padding-bottom: 150px;">
                            <?php
                                $ctr = -1;
                                foreach($level1 as $l1){
                                    $ctr++;
                                    if($ctr == 0){ $pdTop = 70; }
                                    else{ $pdTop = 0; }
                            ?>
                                <input type="hidden" id="hiddenDetailId<?=$ctr?>" value="<?=$l1['detail_id']?>">
                                <li style="padding-top: <?=$pdTop?>px;">
                                    <a id="detail<?=$ctr?>" class="details" style="cursor: pointer;">
                                        <?php
                                            $datenow = date("Y-m-d");
                                            if($l1['detail_end'] < $datenow){
                                                //masanya sudah selesai
                                                ?>
                                                <i class="fa fa-check-square" aria-hidden="true"></i>
                                                <?php
                                            }
                                            else{
                                                //masih in progress
                                                ?>
                                                <i class="fa fa-square-o" aria-hidden="true"></i>
                                                <?php
                                            }
                                        ?>
                                        <b><?=$l1["detail_name"]?></b>&nbsp;
                                        <i class="fa fa-caret-down"></i>
                                    </a>
                                    <div class="dropdown-content" style="margin-left: 15px;" id="dropDownDetail<?=$ctr?>">
                                        <ul style="padding: 0px;">
                                            <li><button data-toggle="modal" style="border: none; width: 160px; text-align: left;" data-target="#myModal" onclick="displayL1(<?=$ctr?>)">Details</button></li>
                                        </ul>
                                    </div> 

                                    <ul class="nav" style="padding-left:30px;">
                                <?php
                                    $subctr = -1;
                                    foreach($level2 as $l2){
                                        $subctr++;
                                        if($l2["detail_id"] == $l1["detail_id"]){
                                ?>
                                        <input type="hidden" id="hiddenSubId<?=$subctr?>" value="<?=$l2['sub_detail_id']?>">
                                        <li>
                                            <a id="subDetail<?=$subctr?>" style="font-size: 12px; max-width: 210px; cursor: pointer; color: dimgray;" class="sub_details" style="padding-left: 15px;">
                                                <?php
                                                    $datenow = date("Y-m-d");
                                                    if($l2['sub_detail_end'] < $datenow){
                                                        //masanya sudah selesai
                                                        ?>
                                                        <i class="fa fa-check-square" aria-hidden="true"></i>
                                                        <?php
                                                    }
                                                    else{
                                                        //masih in progress
                                                        ?>
                                                        <i class="fa fa-square-o" aria-hidden="true"></i>
                                                        <?php
                                                    }
                                                ?>
                                                <?=$l2["sub_detail_name"]?>
                                            </a>
                                            <div class="dropdown-content" style="margin-left: 15px;" id="dropDownSub<?=$subctr?>">
                                                <ul style="padding: 0px;">
                                                    <li>
                                                        <button data-toggle="modal" style="border: none;" data-target="#myModal" onclick="displayL2(<?=$subctr?>,<?=$ctr?>)" class="btnSubDetails">Details</button>
                                                    </li>
                                                    <li>
                                                        <button data-toggle="modal" style="border: none;" data-target="#myModal" onclick="displayAdjust(<?=$subctr?>)" class="btnSubDetails">Adjust</button>
                                                    </li>
                                                </ul>
                                            </div> 
                                        </li>
                                <?php
                                        }
                                    }
                                ?>
                                    </ul>
                                </li>
                            <?php
                                }
                            ?>
                        </ul>
                    </div>
                </div>
                <?php
            }
        ?>
        
        <!-- End Left Sidebar -->
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row bg-title">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <?php 
                        if(isset($chosen_project)){
                            ?>
                            <a class="page-title" style="font-size: 30px;"><?=$chosen_project['project_name']?></a>&nbsp;<em style="font-size: 14px;"><?=date_format(date_create($chosen_project['start_date']), 'd-M-Y');?> s/d <?=date_format(date_create($chosen_project['target_end']), 'd-M-Y');?></em><br>
                            <button style="background-color: black; color: white; border: none; border-radius: 5px; width: 75px; height: 30px; margin-left: 5px;" data-toggle="modal" data-target="#myModal" onclick="displayDetail()">Detail</button>
                            <button style="background-color: black; color: white; border: none; border-radius: 5px; width: 75px; height: 30px; margin-left: 5px;" data-toggle="modal" data-target="#myModal" onclick="displayFiles()">Files</button>
                            <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">

                                  <!-- Modal content-->
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h3 class="box-title">Project Details</h3>
                                    </div>
                                    <div class="modal-body">
                                          <div class="row">
                                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                <div class="white-box">
                                                    <div id="projectHeader">
                                                        Project ID:&nbsp;<h3 style="font-family: arial;"><?=$chosen_project['project_id']?></h3><br>
                                                        Project Name:&nbsp;<b style="font-family: arial black;"><?=$chosen_project['project_name']?></b><br><br>
                                                        Project Value:&nbsp;<b style="font-family: arial black;"><?=number_format($chosen_project['project_total'], 0, '', '.')?></b><br><br>
                                                        Start Date:&nbsp;<b style="font-family: arial black;"><?=$chosen_project['start_date']?></b><br><br>
                                                        Duration (In Days):&nbsp;<b style="font-family: arial black;"><?=$chosen_project['project_duration']?></b><br><br>
                                                        Target End Date:&nbsp;<b style="font-family: arial black;"><?=$chosen_project['target_end']?></b><br><br>
                                                    </div>
                                                    <div id='listFile'>
                                                    Click the name to open file below:<br>
                                                    <?php
                                                        foreach($files as $f){
                                                            $file = "";
                                                            if(strlen($f['filename']) > 38){
                                                                $file = substr($f['filename'], 0, 37);
                                                            }
                                                            else{
                                                                $file = $f['filename'];
                                                            }
                                                            echo "<div style='clear: both;'><div class='singleFile'><a href='./uploads/".$f['filename']."' target='_blank'>$file</a></div><em class='fileDate'>".$f['waktuproses']."</em></div>";
                                                        }
                                                    ?>
                                                    </div>
                                                </div>
                                            </div>
                                         </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                  </div>
                                </div>
                            </div>
                            <?php
                        }
                    ?>
                    
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <?php
                        if(isset($chosen_project)){
                        ?>
                            <div class="white-box analysis-info">
                                <!--Gantt Chart-->
                                        <h1 style="float: left;">Gantt Chart</h1>
                                        <div style="float: right;">
                                            <h3>Last Updated</h3>
                                            <?=$operator." - ".$waktuproses?>
                                        </div>
                                        <div id="guide" style="clear: both; margin-left: 10px; margin-top: 10px;">
                                            <div style="float: left; padding-right: 15px;"><span class="legend" style="background-color: dodgerblue; float: left; margin-top: 5px;"></span>&nbsp;Finished</div>
                                            <div style="float: left; padding-right: 15px; margin-bottom: 10px;"><span class="legend" style="background-color: lightblue; float: left; margin-top: 5px;"></span>&nbsp;In Progress</div>
                                            <div style="float: left; padding-right: 15px; margin-bottom: 10px;"><span class="legend" style="background-color: red; float: left; margin-top: 5px;"></span>&nbsp;Weekend & Holiday</div>
                                            <div style="float: left; padding-right: 15px; margin-bottom: 10px;"><span class="legend" style="background-color: darkorchid; float: left; margin-top: 5px;"></span>&nbsp;Adjust</div>
                                            <div id="guideDate" style=" display: none;"><span class="legend" style="background-color: limegreen; float:left; margin-top: 5px; "></span>&nbsp;Range Date</div>
                                        </div>
                                        <div id="chart-container">
                                            <div id="chart-header">
                                                <ul class="chart-values">
                                                  <?php
                                                    for($i=0;$i<=$maxL1Duration;$i++){
                                                        $curDate = date_create($chosen_project['start_date']);
                                                        date_add($curDate,date_interval_create_from_date_string("$i days"));
                                                        if(date_format($curDate,"D, d M y") == date("D, d M y")){
                                                            //beri tanda jika hari ini
                                                            ?>
                                                            <li style="min-width: 100px; max-width: 100px; background-color: cornflowerblue; color: white;" id="liToday"><?=date_format($curDate,"D, d M y");?></li>
                                                            <?php
                                                        }
                                                        else if(date_format($curDate,"D") == "Sat" || date_format($curDate,"D") == "Sun"){
                                                            //beri tanda jika weekend
                                                            ?>
                                                            <li style="min-width: 100px; max-width: 100px; color: red;" class="liWeekend"><?=date_format($curDate,"D, d M y");?></li>
                                                            <?php
                                                        }
                                                        else{
                                                            ?>
                                                            <li style="min-width: 100px; max-width: 100px;"><?=date_format($curDate,"D, d M y");?></li>
                                                            <?php
                                                        }
                                                    }
                                                  ?>
                                              </ul>
                                            </div>
                                            <div id="task-container">
                                                <ul class="chart-values-hidden">
                                                      <?php
                                                        for($i=0;$i<=$maxL1Duration;$i++){
                                                            //hanya untuk DIVIDER saja, li kosong
                                                            echo "<li></li>";
                                                        }
                                                      ?>
                                                    </ul>
                                                    <ul class="chart-bars">
                                                  <?php
                                                    $ctr = -1;
                                                    foreach($level2 as $l){
                                                        $ctr++;
                                                        $start = date_create($l['sub_detail_start']);
                                                        $end = date_create($l['sub_detail_end']);
                                                        $hundredPercent = date_diff($start, $end)->format("%a")+1;
                                                        $percentAdjust = 0;
                                                        $endAdjusted = date_create('0000-00-00');
                                                        if($l['sub_detail_end'] < date("Y-m-d")){
                                                            //done
                                                            $bgcolor = "dodgerblue";
                                                            $iconcolor = "blue";
                                                        }
                                                        else{
                                                            //in progress
                                                            $bgcolor = "lightblue";                                            
                                                            $iconcolor = "blue";
                                                        }

                                                        foreach($adjusts as $a){
                                                            if($a['sub_detail_id'] == $l['sub_detail_id']){
                                                                $endAdjusted = date_create($l['sub_detail_end']);
                                                                $dur = $a['adjust_duration'];
                                                                $hundredPercent += $dur;
                                                                $percentAdjust = ($dur / $hundredPercent) * 100;
                                                                date_add($endAdjusted,date_interval_create_from_date_string("$dur days"));
                                                            }
                                                        }
                                                        if($endAdjusted > $end){
                                                            //ada adjust thd sub detail berikut
                                                                if($percentAdjust < 50){
                                                                    //adjust lbh kecil
                                                                    ?>
                                                                    <li>
                                                                        <div data-duration="<?=date_format($start,"D, d M y")?>/<?=date_format($endAdjusted,"D, d M y")?>" style="background: linear-gradient(to right, <?=$bgcolor?> <?=100-$percentAdjust?>%, darkorchid <?=$percentAdjust?>%);" class="chart-individual" id="chartItem<?=$ctr?>">
                                                                            <!--trdpt 2 JENIS span: span popup, up & down-->
                                                                            <span style="font-size; 14px;" class="ui custom popup transition hidden" id="popup<?=$ctr?>">
                                                                                <h5><?=$l['sub_detail_name']?></h5>
                                                                                Staff Name: <b><?=$l['staff_name']?></b><br>
                                                                                Staff Note: <b style="color: orange;"><?=$l['staff_note']?></b><br>
                                                                                Flag:
                                                                                    <?php
                                                                                        if($l['flag'] == 1){
                                                                                            echo "<b style='color: green'>Done</b>";
                                                                                        }
                                                                                        else{
                                                                                            echo "<b style='color: grey'>Not Done</b>";
                                                                                        }
                                                                                    ?>
                                                                                <br>
                                                                            </span>
                                                                            <label style="cursor: move; margin: 0; float: left;" class="dragger">
                                                                                <?=$l['sub_detail_name'];?>
                                                                            </label>
                                                                            <!-- Icon yg akan memunculkan detail popup ketika ditekan-->
                                                                            <i class="fa fa-external-link-square" style="color: <?=$iconcolor?>; float: left; padding-top: 3px; padding-left: 5px;" aria-hidden="true"></i>
                                                                        </div>
                                                                    </li>
                                                                    <?php
                                                                }
                                                                else{
                                                                    ?>
                                                                    <li>
                                                                        <div data-duration="<?=date_format($start,"D, d M y")?>/<?=date_format($endAdjusted,"D, d M y")?>" style="background: linear-gradient(to left, darkorchid <?=$percentAdjust?>%, <?=$bgcolor?> <?=100-$percentAdjust?>%);" class="chart-individual" id="chartItem<?=$ctr?>">
                                                                            <!--trdpt 2 JENIS span: span popup, up & down-->
                                                                            <span style="font-size; 14px;" class="ui custom popup transition hidden" id="popup<?=$ctr?>">
                                                                                <h5><?=$l['sub_detail_name']?></h5>
                                                                                Staff Name: <b><?=$l['staff_name']?></b><br>
                                                                                Staff Note: <b style="color: orange;"><?=$l['staff_note']?></b><br>
                                                                                Flag:
                                                                                    <?php
                                                                                        if($l['flag'] == 1){
                                                                                            echo "<b style='color: green'>Done</b>";
                                                                                        }
                                                                                        else{
                                                                                            echo "<b style='color: grey'>Not Done</b>";
                                                                                        }
                                                                                    ?>
                                                                                <br>
                                                                            </span>
                                                                            <label style="margin: 0; float: left;" class="dragger">
                                                                                <?=$l['sub_detail_name'];?>
                                                                            </label>
                                                                            <!-- Icon yg akan memunculkan detail popup ketika ditekan-->
                                                                            <i class="fa fa-external-link-square" style="color: <?=$iconcolor?>; float: left; padding-top: 3px; padding-left: 5px;" aria-hidden="true"></i>
                                                                        </div>
                                                                    </li>
                                                                    <?php
                                                                }
                                                            ?>
                                                            <?php
                                                        }
                                                        else{
                                                            //tidak ada adjust, tidak perlu membagi warna div
                                                            ?>
                                                            <li>
                                                                <div data-duration="<?=date_format($start,"D, d M y")?>/<?=date_format($end,"D, d M y")?>" data-color="<?=$bgcolor?>" class="chart-individual" id="chartItem<?=$ctr?>">
                                                                    <!--trdpt 4 JENIS span: span popup, up & down, dragger, resizers left & right-->
                                                                    <span style="font-size; 14px;" class="ui custom popup transition hidden" id="popup<?=$ctr?>">
                                                                        <h5><?=$l['sub_detail_name']?></h5>
                                                                        Staff Name: <b><?=$l['staff_name']?></b><br>
                                                                        Staff Note: <b style="color: orange;"><?=$l['staff_note']?></b><br>
                                                                        Flag:
                                                                            <?php
                                                                                if($l['flag'] == 1){
                                                                                    echo "<b style='color: green'>Done</b>";
                                                                                }
                                                                                else{
                                                                                    echo "<b style='color: grey'>Not Done</b>";
                                                                                }
                                                                            ?>
                                                                        <br>
                                                                    </span>
                                                                    <label style="margin: 0; float: left;" class="dragger">
                                                                        <?=$l['sub_detail_name'];?>
                                                                    </label>
                                                                    <!-- Icon yg akan memunculkan detail popup ketika ditekan-->
                                                                    <i class="fa fa-external-link-square" style="color: <?=$iconcolor?>; float: left; padding-top: 3px; padding-left: 5px;" aria-hidden="true"></i>
                                                                </div>
                                                            </li>
                                                            <?php
                                                        }
                                                    }
                                                  ?>
                                              </ul>
                                            </div>
                                        </div>
                                        <!--FORM TO SAVE GANTT CHART CHANGES (DRAG & RESIZE)-->
                                        <form action="" method="post">
                                            <input type="hidden" name="id" id="changedL2Id">
                                            <input type="hidden" name="start_date" id="changedL2Start">
                                            <input type="hidden" name="end_date" id="changedL2End">
                                            <input type="submit" style="background-color: green; color: white; border: none; border-radius: 5px; width: 125px; height: 50px; margin-top: 15px; font-size: 16px; display: none" id="btnSaveChange" name="btnSaveChange" value="Save Changes">
                                        </form>
                                        <br>
                                </div>
                                <?php
                            }
                            else{
                                ?>
                                <div class="white-box analysis-info" style="min-height: 500px;">
                                    <div style='margin: 0; position: absolute; top: 100px; left: 50%; transform: translateX(-50%); width: 200px; height: 200px;'><img src='./imgicon/notfound2.jpg' alt='not found' style='width: 100%; height: 100%;'></div>
                                    <h2 style='position: absolute; top: 300px; left: 50%; transform: translateX(-50%);'>No Project found with that id</h2>
                                </div>
                                <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
    </div> 
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="./plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="./plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="./plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="./plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="./plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/semantic.min.js"></script>
    <?php
        if(isset($chosen_project)){
            ?>
            <script>
                var arrDetail, arrSubDetail, arrAdjust, arrHoliday;
                var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];        
                var daysOfMonth = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

                $.ajax({
                     url: "./json/jsonLevel1.php",
                     data: {project_id : "<?=$chosen_project['project_id']?>"},
                     success: function(data){
                         arrDetail = JSON.parse(data);
                         $.ajax({
                             url: "./json/jsonLevel2.php",
                             data: {project_id : "<?=$chosen_project['project_id']?>"},
                             success: function(data){
                                 arrSubDetail = JSON.parse(data);
                                 $.ajax({
                                    url: "./json/jsonFindAdjust.php",
                                    success: function(data){
                                        arrAdjust = JSON.parse(data);
                                        createChartResizeable();
                                        initialize();
                                    },
                                    type: 'GET'
                                });
                             },
                             type: 'GET'
                         });
                     },
                     type: 'GET'
                 });

                $(document).ready(function(){
                    //ambil list holiday            
                    $.ajax({
                        url : "https://www.googleapis.com/calendar/v3/calendars/en.indonesian%23holiday%40group.v.calendar.google.com/events?key=AIzaSyDoCNqjWSoeUS-dYXG0ahB0BI7N9O17E1o&timeMin=<?=$chosen_project['start_date']?>T10:00:00Z&timeMax=<?=$chosen_project['target_end']?>T10:00:00Z",
                        type: 'GET',
                        success: function(data){
                            arrHoliday = data.items;
                            markHolidays();
                        }
                    });

                    $(".chart-individual").mouseenter(function(event){
                        var id = jQuery(this).attr("id");
                        var num = id.substr(9);

                        $(".chart-individual .fa.fa-external-link-square").popup({
                            on: 'click',
                            target   : "#"+id,
                            popup: $("#popup"+num)
                        });
                    });

                    $("#task-container").on("scroll", function(event){
                        var scroll = $("#task-container").scrollLeft();
                        var actualSize = "<?=$ulSize?>"; //size dari ul task
                        actualSize = actualSize.substr(0, actualSize.indexOf('px'));
                        var displayedSize = $("#task-container").css("width"); //size dari div container nya
                        displayedSize = displayedSize.substr(0, displayedSize.indexOf('px'));
                        //actualSize - displayed Size = scroll size

                        //scroll jgn sampai menabrak vertical scroll bar, agar tidka pecah line antara header dan task
                        if(scroll > (actualSize - displayedSize)){
                            scroll = actualSize - displayedSize;
                            $("#task-container").scrollLeft(scroll);
                        }
                        $("#chart-header").scrollLeft(scroll);
                    });
                });

                function markHolidays(){
                    const days = document.querySelectorAll(".chart-values li");
                    const daysArray = [...days];

                    var counter = 0;
                    arrHoliday.forEach(h =>{
                        counter++;
                        //alert(Date.parse(h['date']));
                        var filteredArray = daysArray.filter(day => Date.parse(day.textContent.substr(5)) == Date.parse(h['start']['date'].split("-").join("/")));
                        if(filteredArray.length > 0){
                            filteredArray[0].className = "liHoliday";
                            filteredArray[0].id = "liHoliday"+counter;
                            filteredArray[0].style.color = "red";
                            $("#liHoliday"+counter).popup({
                                postion: "top center",
                                target   : "#liHoliday"+counter,
                                title    : 'Holiday',
                                content  : h['summary']
                            });
                        }
                    });
                }

                function createChartResizeable(e) {
                  const days = document.querySelectorAll(".chart-values li");
                  const tasks = document.querySelectorAll(".chart-bars div");
                  const taskLabel = document.querySelectorAll(".chart-bars div label");
                  const rightResizers = document.querySelectorAll(".chart-bars .resizers.right");
                  const daysArray = [...days];

                  for (let index = 0; index < tasks.length; index++) {
                        const el = tasks[index];
                        const label = taskLabel[index];
                        const right = rightResizers[index];
                        const duration = el.dataset.duration.split("/");
                        const startDay = duration[0];
                        const endDay = duration[1];
                        let left = 0;
                        let width = 0;

                        var filteredArray = daysArray.filter(day => day.textContent == String(startDay));
                        left = filteredArray[0].offsetLeft;

                        filteredArray = daysArray.filter(day => day.textContent == endDay);
                        width = filteredArray[0].offsetLeft + filteredArray[0].offsetWidth - left;

                        // apply css

                        el.style.left = left+"px";
                        el.style.width = width+"px";
                        label.style.maxWidth = (parseInt(width)-50)+"px";

                        el.style.backgroundColor = el.dataset.color;
                        el.style.opacity = 1;
                  }
                }

                function resizeContainer(){
                    var initialHeight = "<?=$divSize?>";
                    if(initialHeight > window.innerHeight-350){
                        //jika terlalu besar, kurangi height nya
                        $("#chart-container").css("height", window.innerHeight-350+"px");
                        $("#task-container").css("height", window.innerHeight-420+"px");
                    }
                    else{
                        //jika tidak terlalu besar, ikut height awal yg sudah diinisialiasi dr php 
                        $("#chart-container").css("height", initialHeight+"px");
                        $("#task-container").css("height", (initialHeight-20)+"px");
                    }
                }

                function initialize(){
                    var top = 0, counter = 0;
                    arrSubDetail.forEach(s =>{
                        counter++;
                        if((Date.parse(s['sub_detail_end']) > Date.parse("<?=date('Y/m/d')?>")) && top == 0){
                            top = counter*37;
                        }
                    });
                    $("#task-container").scrollTop(top);

                    //scroll otomatis hingga tanggal HARI INI di paling kiri
                    var today = "<?=date('Y/m/d')?>";
                    const days = document.querySelectorAll(".chart-values li");
                    const daysArray = [...days];

                    var filteredArray = daysArray.filter(day => Date.parse(day.textContent.substr(5)) == Date.parse(today));
                    if(filteredArray.length >= 1){
                        $("#task-container").scrollLeft(filteredArray[0].offsetLeft);
                        $("#chart-header").scrollLeft(filteredArray[0].offsetLeft);
                    }
                }
                
                function displayDetail(){
                    $(".box-title").html("Project Details");
                    $("#projectHeader").css("display", "block");
                    $("#listFile").css("display", "none");
                }
                
                function displayFiles(){
                    $(".box-title").html("Uploaded Files");
                    $("#projectHeader").css("display", "none");
                    $("#listFile").css("display", "block");
                }

                window.onclick = function(event) {
                    if (event.target.classList.contains("fa-external-link-square")) {
                        $(".chart-individual .fa.fa-external-link-square").popup();
                    }

                    if (!event.target.matches(lastDisplayed)) {
                        $(".dropdown-content").css("display", "none");
                    }
                }

                window.onresize = function(event){
                    resizeContainer();
                }
            </script>
            <?php
        }
    ?>
    
</body>
</html>