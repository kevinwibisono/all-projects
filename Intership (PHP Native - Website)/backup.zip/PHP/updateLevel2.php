<?php
    include("connection.php"); 
    date_default_timezone_set("Asia/Bangkok");
    $name = $_POST['name'];
    $sub_id = $_POST['sub_id'];
    $flag = $_POST['flag'];
    $datenow = date("Y-m-d H:i:s");

    mysqli_query($conn, "UPDATE project_detail_l2 SET flag = $flag, operator = '$name', waktuproses = '$datenow' WHERE sub_detail_id = '$sub_id'");
?>