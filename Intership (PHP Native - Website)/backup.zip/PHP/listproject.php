<?php
    include("connection.php");
    date_default_timezone_set("Asia/Bangkok");
    session_start();
    $visibility = "visible"; $menuDua = "Master Project";
    $current_staff = []; $current_name = "--";
    if(isset($_SESSION['staff_login'])){
        $current_staff = $_SESSION['staff_login'];
        $current_name = $current_staff['staff_name'];
        if($current_staff['flgAsAdmin'] == 0){
            $visibility = "hidden";
            $menuDua = "Projects";
        }
    }
    else{
        header("location:index.php");
    }
    $error = "";
    $query = "SELECT p.project_id, project_name, project_total, start_date, project_duration, DATE_ADD(start_date, INTERVAL project_duration DAY) as target_end, max(l.detail_end) as max_detail FROM project_header p LEFT JOIN project_detail_l1 l ON(l.project_id = p.project_id) GROUP BY p.project_id";
    if($current_staff['flgAsAdmin'] == 0){
        $id = $current_staff['staff_id'];
        $query = "SELECT p.project_id, project_name, project_total, start_date, project_duration, DATE_ADD(start_date, INTERVAL project_duration DAY) as target_end, max(l.detail_end) as max_detail FROM project_header p, project_detail_l1 l, project_detail_l2 l2 WHERE l.project_id = p.project_id and l.detail_id = l2.detail_id and l2.staff_id = '$id' GROUP BY p.project_id";
    }

    if(isset($_POST['detail'])){
        $id = $_POST['id'];
        $result = mysqli_query($conn, "SELECT project_id, project_name, project_total, start_date, project_duration, DATE_ADD(start_date, INTERVAL project_duration DAY) as target_end
 FROM project_header WHERE project_id = '$id'");
        while($row = mysqli_fetch_array($result)){
            $data["project_id"] = $row["project_id"];
            $data["project_name"] = $row["project_name"];
            $data["project_total"] = $row["project_total"];
            $data["start_date"] = $row["start_date"];
            $data["project_duration"] = $row["project_duration"];
            $data["target_end"] = $row["target_end"];
        }
        mysqli_free_result($result);
        
        $_SESSION["chosen_project"] = $data;
        header("location:project.php");
    }

    if(isset($_POST['add'])){
        $datenow = date("Y-m-d H:i:s");
        $project_id = $_POST['id'];
        $project_name = $_POST['name'];
        $project_value = $_POST['value'];
        $start_date = $_POST['start_date'];
        $duration = $_POST['duration'];
        
        mysqli_query($conn, "INSERT INTO project_header VALUES('$project_id', '$project_name', $project_value, '$start_date', $duration)");
    }

    if(isset($_POST['update'])){
        //Ketika update start_date dari proyek
        //1. Majukan juga semua start_date dari detail level 1 dan level 2 yang berada di blkg/sebelum start_date yg baru
        //2. Jika pada detail level 1 / level 2 ada yang juga dibelakang start_date baru, majukan juga
        $datenow = date("Y-m-d H:i:s");
        $project_id = $_POST['id'];
        $project_name = $_POST['name'];
        $project_value = $_POST['value'];
        $start_date = $_POST['start_date'];

        $duration = $_POST['duration'];
        
        $result = mysqli_query($conn, "SELECT * FROM project_detail_l1 WHERE project_id = '$project_id'");
        while($row = mysqli_fetch_array($result)){
            $detail_id = $row['detail_id'];

            $res = mysqli_query($conn, "SELECT * FROM project_detail_l2 WHERE detail_id = '$detail_id'");
            while($r = mysqli_fetch_array($res)){
                $sub_id = $r['sub_detail_id'];
                if($r['sub_detail_start'] < $start_date){
                    if($r['sub_detail_end'] < $start_date){
                        //ex: 27-06-2020 s/d 30-06-2020
                        //changed start_date to 01-07-2020
                        mysqli_query($conn, "UPDATE project_detail_l2 SET sub_detail_start = '$start_date', sub_detail_end = '$start_date', operator = '$current_name', waktuproses = '$datenow' WHERE sub_detail_id = '$sub_id'");
                    }
                    else{//ex: 27-06-2020 s/d 30-06-2020
                        //changed start_date to 28-06-2020
                        mysqli_query($conn, "UPDATE project_detail_l2 SET sub_detail_start = '$start_date', operator = '$current_name', waktuproses = '$datenow' WHERE sub_detail_id = '$sub_id'");
                    }
                }
            }

            if($row['detail_start'] < $start_date){
                if($row['detail_end'] < $start_date){
                    mysqli_query($conn, "UPDATE project_detail_l1 SET detail_start = '$start_date', detail_end = '$start_date', operator = '$current_name', waktuproses = '$datenow' WHERE detail_id = '$detail_id'");
                }
                else{
                    mysqli_query($conn, "UPDATE project_detail_l1 SET detail_start = '$start_date', operator = '$current_name', waktuproses = '$datenow' WHERE detail_id = '$detail_id'");
                }
            }
        }

        mysqli_query($conn, "UPDATE project_header SET project_name = '$project_name', project_total = '$project_value', start_date = '$start_date', project_duration = '$duration' WHERE project_id = '$project_id'");
    }

    if(isset($_POST['delete'])){
        $project_id = $_POST['id'];
        
        //URUTAN delete project:
        $result = mysqli_query($conn, "SELECT detail_id FROM project_detail_l1 WHERE project_id = '$project_id'");
        while($row = mysqli_fetch_array($result)){
            $detail_id = $row['detail_id'];

            //1. delete adjust
            $res = mysqli_query($conn, "SELECT sub_detail_id FROM project_detail_l2 WHERE detail_id = '$detail_id'");
            while($r = mysqli_fetch_array($res)){
                $sub_id = $r['sub_detail_id'];
                mysqli_query($conn, "DELETE FROM project_adjust WHERE sub_detail_id = '$sub_id'");
            }

            //2. delete level 2
            mysqli_query($conn, "DELETE FROM project_detail_l2 WHERE detail_id = '$detail_id'");
        }
        //3. delete level 1
        mysqli_query($conn, "DELETE FROM project_detail_l1 WHERE project_id = '$project_id'");
        //4. delete staff khusus
        mysqli_query($conn, "DELETE FROM master_staff WHERE project_id = '$project_id'");
        //5. delete project
        mysqli_query($conn, "DELETE FROM project_header WHERE project_id = '$project_id'");
    }

    if(isset($_POST['filter'])){
        $startRange = $_POST['r_date_start'];
        $endRange = $_POST['r_date_end'];
        if($startRange == null){
            $startRange = '0000-00-00';
        }
        if($endRange == null){
            $endRange = '9999-12-31';
        }
        $query = "SELECT *, DATE_ADD(start_date, INTERVAL project_duration DAY) as target_end
        FROM project_header WHERE start_date between date('$startRange') and date('$endRange')";
    }

    $projectList = [];

    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_array($result)){
        $data["project_id"] = $row["project_id"];
        $data["project_name"] = $row["project_name"];
        $data["project_total"] = $row["project_total"];
        $data["start_date"] = $row["start_date"];
        $data["project_duration"] = $row["project_duration"];
        $data["target_end"] = $row["target_end"];
        
        array_push($projectList, $data);
    } 
    mysqli_free_result($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="./imgicon/logo2.ico">
    <title>Project Scheduling</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="./plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="./plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="./plugins/bower_components/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
    <link href="css/graph.css" rel="stylesheet">
    <!-- CSS for datatable-->
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
    <style>
        #tableProjects i:hover{
            transform: scale(2);
        }
        #topBtn {
          display: none;
          position: fixed;
          bottom: 20px;
          right: 30px;
          z-index: 99;
          font-size: 18px;
          border: none;
          outline: none;
          background-color: red;
          color: white;
          cursor: pointer;
          padding: 15px;
          border-radius: 5px;
        }
        
        .sorting::after{display: none;}
        
        .sorting_desc::after{display: none;}
        
        .sorting_asc::after{display: none;}
        
        .singleFile{
            border: 1px solid black;
            margin: 10px;
            padding: 5px;
            max-height: 32px;
            max-width: 300px;
            float: left;
        }
        
        .singleFile i{
            display: none;
        }
        
        em{
            float: left;
            margin-top: 15px;
        }
        
        #addProjectStaffDiv{
            max-width: 300px;
            display: none;
            border: 1px solid black;
        }
    </style>
    <script>
        var oldName = "";
    </script>
</head>

<body class="fix-header">
    <!-- Preloader -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <!-- Wrapper -->
    <div id="wrapper">
        <!-- Topbar header - style you can find in pages.scss -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                    <!-- Logo -->
                    <a class="logo" href="dashboard.php">
                        <!-- Logo icon image, you can use font-icon also -->
                        <b>
                            <img src="./imgicon/logo2.ico" style="width: 25px; height: 30px" alt="home" class="light-logo" />
                        </b>
                        <!-- Logo text image you can use text also -->
                        <span class="hidden-xs">
                            <h2 style="float: left; font-family: arial; padding-top: 5px; padding-left: 10px">SoftQ</h2>
                        </span> 
                    </a>
                </div>
                <!-- /Logo -->
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="nav-toggler open-close waves-effect waves-light hidden-md hidden-lg" href="javascript:void(0)"><i class="fa fa-bars"></i></a>
                    </li>
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><img src="./imgicon/AIQ61.png" alt="user-img" width="36" class="img-circle">&nbsp;<b class="hidden-xs"><?=$current_name?></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="index.php" class="waves-effect"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;<b>Logout</b></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- End Top Navigation -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    <li style="padding: 70px 0 0;">
                        <a href="dashboard.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="listproject.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i><?=$menuDua?></a>
                    </li>
                    <li style="visibility: <?=$visibility?>">
                        <a href="teams.php" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Master Staff</a>
                    </li>
                </ul>
            </div>
            
        </div>
        <!-- End Left Sidebar -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><a href="listproject.php">List Of Projects</a></h4></div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <button id="topBtn" title="Go to top">Top</button>
                            <!-- ============================================================== -->
                            <!-- Modals -->
                            <!-- ============================================================== -->
                            <div class="modal fade" id="modal" role="dialog">
                                <div class="modal-dialog">

                                  <!-- Modal content-->
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h3 class="modal-title">Add New Project</h3>
                                    </div>
                                    <div class="modal-body">
                                          <div class="row">
                                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                <div class="white-box">
                                                    <form action="" method="post" id="formAdd">
                                                        Project ID:<br><input type="text" name="id" id="addProjectId"><br><br>
                                                        Project Name:<br><input type="text" name="name" id="addProjectName" placeholder="ex: PHP Project"><br><br>
                                                        Project Value:<br><input type="number" min="1" name="value" id="addProjectTotal" placeholder="million rupiahs"><br><br>
                                                        Start Date:<br><input type="date" name="start_date" id="addProjectDate"><br><br>
                                                        Project Duration (In Days):<br><input type="number" name="duration" min="1" id="addProjectDuration" placeholder="ex: 60 days"><br><br>
                                                        <input type="submit" value="Add" style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px;" name="add">
                                                        <h3 style="color: red;" id="errorMsg"></h3>
                                                    </form>

                                                    <form method="post" id="formFilter">
                                                        Start Date Range:<br>
                                                        From:&nbsp;<input type="date" name="r_date_start">&nbsp;-&nbsp;To:&nbsp;<input type="date" name="r_date_end"><br><br>
                                                        <input type="submit" value="Apply Filter" style="background-color: black; color: white; border: none; border-radius: 5px; width: 100px; height: 40px;" name="filter">
                                                    </form>

                                                    <form action="" method="post" id="formUpdate">
                                                        Project ID:<br><input type="text" style="border: none; font-size: 20px; text-decoration: bold;" readonly="true" name="id" id="updateProjectId"><br><br>
                                                        Project Name:<br><input type="text" name="name" id="updateProjectName" placeholder="ex: PHP Project"><br><br>
                                                        Project Value:<br><input type="number" name="value" min="1" id="updateProjectTotal" placeholder="rupiahs"><br><br>
                                                        Start Date:<br><input type="date" name="start_date" id="updateProjectDate"><br><br>
                                                        Project Duration (In Days):<br><input type="number" min="1" name="duration" id="updateProjectDuration" placeholder="ex: 60 days"><br><br>
                                                        <div id="addProjectStaffDiv">
                                                            Add New Staff: <br>
                                                            Staff Name:<br><input type="text" id="addProjectStaffName" placeholder="name"><br><br>
                                                            Staff Password:<br><input type="text" id="addProjectStaffPassword" placeholder="name"><br><br>
                                                            Staff Position:<br><input type="text" id="addProjectStaffPosition" placeholder="ex: Project Manager"><br><br>
                                                            <input type="submit" id="addProjectStaff" style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px;" value="Add">
                                                            <h3 style="color: red;" id="errorProjectStaff"></h3>
                                                        </div><br>
                                                        <button id="toggle">Add New Staff</button><br><br>
                                                        List Of Project Staff:
                                                        <div class="table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>#</th>
                                                                        <th>ID</th>
                                                                        <th>NAME</th>
                                                                        <th>PASSWORD</th>
                                                                        <th>POSITION</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="tableBody"></tbody>
                                                            </table>
                                                        </div><br><br>
                                                        <input type="submit" value="Update" style="background-color: black; color: white; border: none; border-radius: 5px; width: 75px; height: 40px;" name="update">
                                                        <h3 style="color: red;" id="errorMsgUpdate"></h3>
                                                    </form>
                                                    
                                                    <form action="" method="post" id="formUpload" enctype="multipart/form-data">
                                                        <input type='hidden' name='id' id='uploadProjectId'>
                                                        Upload New File:<br><input type="file" id="uploadFile"><br>
                                                        <input type="button" value="Upload" style="background-color: black; color: white; border: none; border-radius: 5px; width: 55px; height: 25px;" id="uploadBtn">
                                                        <h3 style="color: grey" id="errorMsgUpload"></h3><br>
                                                        Uploaded Files:<br>
                                                        <div id='listFile'></div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal" onclick="resetFieldsProject()">Close</button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            
                            <!-- ============================================================== -->
                            <!-- End Modals -->
                            <!-- ============================================================== -->
                            
                            <button style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px; margin-bottom: 10px; visibility: <?=$visibility?>" data-toggle="modal" data-target="#modal" onclick="displayAdd()">Add</button>
                            
                            <button style="background-color: black; color: white; border: none; border-radius: 5px; width: 50px; height: 25px; visibility: <?=$visibility?>" data-toggle="modal" data-target="#modal" onclick="displayFilter()">Filter</button>
                            
                            <div class="table-responsive">
                                <table id="tableProjects" class="display">
                                    <thead>
                                        <tr>
                                            <th style="text-align: right;">#</th>
                                            <th style="text-align: right;">ACTION</th>
                                            <th style="text-align: left;">NAME</th>
                                            <th style="text-align: right;">VALUE (Rp)</th>
                                            <th style="text-align: center;">START</th>
                                            <th style="text-align: center;">DURATION (DAYS)</th>
                                            <th style="text-align: center;">TARGET END DATE</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                                $ctr = 0;
                                                foreach ($projectList as $p){
                                                    $ctr++;
                                        ?>
                                                    <tr>
                                                        <td style="text-align: right;"><?=$ctr?></td>
                                                        <td>
                                                            <form method="post" style="float:right;">
                                                                <input type="hidden" name="id" value="<?=$p['project_id']?>" id="projectId<?=$ctr?>">
                                                                <button type="submit" name="detail" style="border: none; background-color: transparent;">
                                                                    <i class="fa fa-info-circle" aria-hidden="true"></i>
                                                                </button>
                                                            </form>
                                                            
                                                            <button data-toggle="modal" data-target="#modal" style="border: none; background-color: transparent; float:right; visibility: <?=$visibility?>" onclick="displayUpload(<?=$ctr?>)">
                                                                <i class="fa fa-folder-open" style="color: goldenrod;" aria-hidden="true"></i>
                                                            </button>
                                                            
                                                            <button data-toggle="modal" data-target="#modal" style="border: none; background-color: transparent; float:right; visibility: <?=$visibility?>" onclick="displayProject(<?=$ctr?>)">
                                                                <i class="fa fa-pencil-square" style="color: blue;" aria-hidden="true"></i>
                                                            </button>
                                                            
                                                            <form method="post" id="deleteProjectId<?=$ctr?>" class="formDelete" style="float:right;">
                                                                <input type="hidden" name="id" value="<?=$p['project_id']?>">
                                                                <button type="submit" class="btnDelete" name="delete" style="border: none; background-color: transparent; visibility: <?=$visibility?>">
                                                                    <i class="fa fa-trash" style="color: red;" aria-hidden="true"></i>
                                                                </button>
                                                            </form>
                                                        </td>
                                                        <td style="text-align: left;"><?=$p['project_name']?></td>
                                                        <td style="text-align: right;"><?=number_format($p['project_total'], 0, '', '.')?></td>
                                                        <td style="text-align: center;"><?=date_format(date_create($p['start_date']), "d M Y")?></td>
                                                        <td style="text-align: center;"><?=$p['project_duration']?></td>
                                                        <td style="text-align: center;"><?=date_format(date_create($p['target_end']), "d M Y")?></td>
                                                    </tr>
                                        <?php
                                                }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </div>
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <script src="./plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="./plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="./plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="./plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="./plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="./plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="./plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script>
        var arrProject, arrFile, current_project_id;
        $(document).ready(function () {
            $.ajax({
                url: "./json/jsonProject.php",
                success: function(data){
                    arrProject = JSON.parse(data);
                }, 
                type: 'GET'
            });

            $('#tableProjects').DataTable({
                "lengthMenu": [[-1, 10, 25, 50], ["All", 10, 25, 50]]
            });

            $("#formAdd").submit(function(event){
                var projectName = $("#addProjectName").val();
                var projectId = $("#addProjectId").val();
                var projectTotal = $("#addProjectTotal").val();
                var projectDate = $("#addProjectDate").val();
                var projectDuration = $("#addProjectDuration").val();
                if(projectName == "" || projectDate == "" || projectId == "" || projectTotal == "" || projectDuration == ""){
                    $("#errorMsg").html("Fields must not be null");
                    event.preventDefault();
                }
                else {
                    var unique = true;
                    for(var i=0;i<arrProject.length;i++){
                        if(arrProject[i].project_name == projectName || arrProject[i].project_id == projectId){
                            unique = false;
                        }
                    }
                    if(!unique){
                        $("#errorMsg").html("Project name and ID must be unique");
                        event.preventDefault();
                    }
                    else{
                        $("#errorMsg").html("");
                    }
                }                
            });

            $("#formUpdate").submit(function(event){
                var projectName = $("#updateProjectName").val();
                var projectTotal = $("#updateProjectTotal").val();
                var projectDate = $("#updateProjectDate").val();
                var projectDuration = $("#updateProjectDuration").val();
                if(projectName == "" || projectDate == "" || projectTotal == "" || projectDuration == ""){
                    $("#errorMsgUpdate").html("Fields must not be null");
                    event.preventDefault();
                }
                else {
                    if(projectName != oldName){
                        var unique = true;
                        for(var i=0;i<arrProject.length;i++){
                            if(arrProject[i].project_name == projectName){
                                unique = false;
                            }
                        }
                        if(!unique){
                            $("#errorMsgUpdate").html("Project name must be unique");
                            event.preventDefault();
                        }
                        else{
                            $("#errorMsgUpdate").html("");
                        }
                    }
                    else{
                        $("#errorMsgUpdate").html("");
                    }
                }                
            });

            $(".btnDelete").click(function(event){
                var form = $(this).parent();
                var orderNumber = form.attr('id');
                orderNumber = orderNumber.substr(15);
                var id = $("#projectId"+orderNumber).val();
                var namaProject = "";
                arrProject.forEach(p => {
                    if(p['project_id'] == id){
                        namaProject = p['project_name'];
                    }
                });

                var cfr = confirm("Are you sure you want to delete "+namaProject+"?");
                if(cfr){
                    var cfr2 = confirm("WARNING! Deleting project will also delete its details and staffs. Do you still want to continue?");
                    if(!cfr2){
                        event.preventDefault();
                    }
                }
                else{
                    event.preventDefault();
                }

            });

            $("#topBtn").click(function(){
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            });
            
            $("#uploadBtn").click(function(){
                var file_data = $('#uploadFile').prop('files')[0]; 
				if(file_data != undefined){
					$("#uploadFile").attr("disabled", "disabled");
					$("#uploadBtn").css("background-color", "lightgrey");
					$("#uploadBtn").attr("disabled", "disabled");
					$("#errorMsgUpload").css("color", "grey");
					$("#errorMsgUpload").html("Uploading...");
					var form_data = new FormData();
					form_data.append('file', file_data);
					form_data.append("id", current_project_id);
					form_data.append("staff_name", "<?=$current_staff['staff_name']?>");
					$.ajax({
						url: "upload.php",
						data: form_data,
						success: function(){
							$("#uploadFile").removeAttr("disabled");
							$("#uploadBtn").css("background-color", "black");
							$("#uploadBtn").removeAttr("disabled");
							$("#errorMsgUpload").html("");
							refreshListFile();
						},
						processData: false,
						contentType: false,
						method: 'post'
					});
				}
                else{
					$("#errorMsgUpload").css("color", "red");
					$("#errorMsgUpload").html("File must be selected");
				}
            });
            
            $("#toggle").click(function(){
                event.preventDefault();
                var displayDiv = $("#addProjectStaffDiv").css("display");
                if(displayDiv == "block"){
                    $("#toggle").html("Add New Staff");
                    $("#addProjectStaffDiv").css("display", "none");
                }
                else{
                    $("#toggle").html("Hide Form");
                    $("#addProjectStaffDiv").css("display", "block");
                }
            });
            
            $("#addProjectStaff").click(function(){
                event.preventDefault();
                var name = $("#addProjectStaffName").val();
                var password = $("#addProjectStaffPassword").val();
                var position = $("#addProjectStaffPosition").val();
                if(name == "" || password == "" || position == ""){
                    $("#errorProjectStaff").html("Field must not be null");
                }
                else{
                    $("#errorProjectStaff").html("");
                    $.ajax({
                        url: "addprojectstaff.php",
                        data: {
                            current_staff: "<?=$current_staff['staff_name']?>",
                            staff_name: name,
                            password: password,
                            position: position,
                            project_id: $("#updateProjectId").val(),
                        },
                        success: function(){
                            refreshListProjectStaff();
                            $("#addProjectStaffName").val("");
                            $("#addProjectStaffPassword").val("");
                            $("#addProjectStaffPosition").val("");
                            $("#addProjectStaffName").focus();
                        },
                        method: 'post'
                    });
                }
            });
        });
        
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            $("#topBtn").css("display", "block");
          } else {
            $("#topBtn").css("display", "none");
          }
        }
        
        function deleteFile(num){
            event.preventDefault();
            $.ajax({
                url: "deleteUpload.php",
                data: {fileId: $("#fileId"+num).val(), filename: $("#filename"+num).val()},
                success: function(){
                    refreshListFile();
                },
                method: 'post'
            })
        }
        
        function resetFieldsProject(){
            $("#addProjectId").val("");
            $("#addProjectName").val("");
            $("#addProjectTotal").val("");
            $("#addProjectDate").val("");
            $("#addProjectDuration").val("");
            $("#errorMsg").html("");
        }
        
        function resetFieldsUProject(){
            $("#errorMsgUpdate").html("");
        }
        
        function displayProject(num){
            changeModal("block", "none", "none", "none");
            var id = $("#projectId"+num).val();
            current_project_id = id;
            var project = [];
            arrProject.forEach(p => {
                if(p['project_id'] == id){
                    project = p;
                }
            });
            
            oldName = project['project_name'];
            
            $(".modal-title").html(project['project_name']);

            $("#updateProjectId").val(project['project_id']);
            $("#updateProjectName").val(project['project_name']);
            $("#updateProjectTotal").val(project['project_total']);
            $("#updateProjectDate").val(project['start_date']);
            $("#updateProjectDuration").val(project['project_duration']);
            refreshListProjectStaff();
        }

        function displayAdd(){
            $(".modal-title").html("Add New Project");
            changeModal("none", "block", "none", "none");
        }
        
        function displayUpload(num){
            current_project_id = $("#projectId"+num).val(), nama = "";
            arrProject.forEach(a =>{
                if(a['project_id'] == current_project_id){
                    nama = a['project_name'];
                }
            });
            $("#uploadProjectId").val(current_project_id);
            $(".modal-title").html(nama);
            changeModal("none", "none", "none", "block");
            $("#listFile").html("");
            refreshListFile();
        }

        function displayFilter(){
            $(".modal-title").html("Filter Project");
            changeModal("none", "none", "block", "none");
        }
        
        function changeModal(update, add, filter, upload){
            $("#formUpdate").css("display", update);
            $("#formAdd").css("display", add);
            $("#formFilter").css("display", filter);
            $("#formUpload").css("display", upload);
        }
        
        
        function refreshListFile(){
            $("#listFile").html("");
            $.ajax({
                url: "./json/jsonFile.php",
                data: {"project_id" : current_project_id},
                success: function(data){
                    var arrFile = JSON.parse(data);
                    var counter = 0;
                    arrFile.forEach(f => {
                        counter++;
                        var file = "";
                        if(String(f['filename']).length > 38){
                            file = String(f['filename']).substr(0, 37);
                        }
                        else{
                            file = f['filename'];
                        }
                        $("#listFile").append("<div style='clear: both;'><div class='singleFile' id='singleFile"+counter+"'><a href='./uploads/"+f['filename']+"' target='_blank'>"+file+"</a></div><em>"+f['waktuproses']+"</em></div>");
                        $("#singleFile"+counter).append("<form method='post' style='float: right;'><input type='hidden' id='filename"+counter+"' value="+f['filename']+"><input type='hidden' id='fileId"+counter+"' value='"+f['file_id']+"'><button style='border:none; background-color: white;' id='deleteFile"+counter+"' onclick='deleteFile("+counter+")'><i class='fa fa-times' aria-hidden='true'></i></button></form>");
                    });
                    $(".singleFile").mouseenter(function(){
                        var id = jQuery(this).attr("id");
                        $("#"+id+" i").css("display", "inline");
                    });
                    $(".singleFile").mouseleave(function(){
                        var id = jQuery(this).attr("id");
                        $("#"+id+" i").css("display", "none");
                    });
                    $("#uploadFile").val(null);
                },
                method: 'get'
            });
        }
        
        function refreshListProjectStaff(){
            $("#tableBody").html("");
            $.ajax({
                url: "./json/listprojectstaff.php",
                data: {project_id: $("#updateProjectId").val()},
                success: function(data){
                    var arrProjectStaff = JSON.parse(data);
                    var counter = 0;
                    arrProjectStaff.forEach(a => {
                        counter++;
                        $("#tableBody").append("<tr id='row"+counter+"'></tr>");
                        
                        $("#row"+counter).append("<td>"+counter+"</td><td>"+a['staff_id']+"</td><td>"+a['staff_name']+"</td><td>"+a['Password']+"</td><td>"+a['staff_position']+"</td>");
                    });
                }
            });
        }
    </script>
</body>

</html>