<?php
    $conn = mysqli_connect("localhost", "root", "", "u335219020_softq");
?>